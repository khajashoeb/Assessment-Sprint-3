function showInfo(name) {
  alert("You clicked on " + name + "'s profile!");
}
